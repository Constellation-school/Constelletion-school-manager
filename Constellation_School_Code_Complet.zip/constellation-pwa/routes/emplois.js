// routes/emplois.js
const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const router  = express.Router();
router.use(auth);

router.get('/', async (req, res) => {
  try {
    const { classe_id, enseignant_id } = req.query;
    const etabId = req.user.etablissement_id;
    let query = `
      SELECT e.*, c.nom AS classe, m.nom_fr AS matiere,
             CONCAT(u.nom,' ',u.prenom) AS enseignant
      FROM emplois_du_temps e
      JOIN classes c ON c.id = e.classe_id
      JOIN matieres m ON m.id = e.matiere_id
      JOIN utilisateurs u ON u.id = e.enseignant_id
      JOIN annees_scolaires a ON a.id = e.annee_id AND a.active = 1
      WHERE c.etablissement_id = ?
    `;
    const params = [etabId];
    if (classe_id)     { query += ' AND e.classe_id = ?';     params.push(classe_id); }
    if (enseignant_id) { query += ' AND e.enseignant_id = ?'; params.push(enseignant_id); }
    query += ' ORDER BY FIELD(e.jour,"Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"), e.heure_debut';
    const [edt] = await db.query(query, params);
    res.setHeader('Cache-Control', 'private, max-age=3600');
    res.json({ success: true, data: edt });
  } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

router.post('/', async (req, res) => {
  try {
    const { classe_id, enseignant_id, matiere_id, jour, heure_debut, heure_fin, salle } = req.body;
    const etabId = req.user.etablissement_id;
    const [[annee]] = await db.query('SELECT id FROM annees_scolaires WHERE etablissement_id=? AND active=1 LIMIT 1',[etabId]);
    // Vérifier les conflits
    const [conflits] = await db.query(
      'SELECT id FROM emplois_du_temps WHERE (classe_id=? OR enseignant_id=?) AND annee_id=? AND jour=? AND ((heure_debut < ? AND heure_fin > ?) OR (heure_debut < ? AND heure_fin > ?))',
      [classe_id, enseignant_id, annee.id, jour, heure_fin, heure_debut, heure_fin, heure_debut]
    );
    if (conflits.length > 0) return res.status(409).json({ error: 'Conflit d\'horaire détecté' });
    const [r] = await db.query(
      'INSERT INTO emplois_du_temps (classe_id, annee_id, enseignant_id, matiere_id, jour, heure_debut, heure_fin, salle) VALUES (?,?,?,?,?,?,?,?)',
      [classe_id, annee.id, enseignant_id, matiere_id, jour, heure_debut, heure_fin, salle]
    );
    res.status(201).json({ success: true, data: { id: r.insertId } });
  } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

module.exports = router;
