// routes/classes.js
const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const router  = express.Router();
router.use(auth);

router.get('/', async (req, res) => {
  try {
    const [classes] = await db.query(
      `SELECT c.*, n.nom AS niveau, COUNT(i.eleve_id) AS effectif
       FROM classes c
       JOIN niveaux n ON n.id = c.niveau_id
       JOIN annees_scolaires a ON a.id = c.annee_id AND a.active = 1
       LEFT JOIN inscriptions i ON i.classe_id = c.id AND i.annee_id = a.id
       WHERE c.etablissement_id = ?
       GROUP BY c.id ORDER BY n.ordre, c.nom`,
      [req.user.etablissement_id]
    );
    res.setHeader('Cache-Control', 'private, max-age=600');
    res.json({ success: true, data: classes });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { nom, niveau_id, effectif_max, salle } = req.body;
    const etabId = req.user.etablissement_id;
    const [[annee]] = await db.query('SELECT id FROM annees_scolaires WHERE etablissement_id=? AND active=1 LIMIT 1',[etabId]);
    if (!annee) return res.status(400).json({ error: 'Aucune année scolaire active' });
    const [r] = await db.query(
      'INSERT INTO classes (etablissement_id, annee_id, niveau_id, nom, effectif_max, salle) VALUES (?,?,?,?,?,?)',
      [etabId, annee.id, niveau_id, nom, effectif_max || 60, salle]
    );
    res.status(201).json({ success: true, data: { id: r.insertId } });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});
module.exports = router;
