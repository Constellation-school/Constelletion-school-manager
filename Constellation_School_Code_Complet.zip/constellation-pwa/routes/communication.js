// ============================================================
// ROUTES/COMMUNICATION.JS — Envoi WhatsApp & SMS
// Constellation School — Patrick TALLA — 2025
// ============================================================

const express   = require('express');
const db        = require('../config/database');
const auth      = require('../middleware/auth');
const { requireRole } = require('../middleware/auth');
const whatsapp  = require('../services/whatsapp');
const router    = express.Router();

router.use(auth);

// ---- ENVOYER UN MESSAGE WHATSAPP ----
router.post('/whatsapp/envoyer', requireRole('directeur','censeur','super_admin'), async (req, res) => {
  try {
    const { type, destinataires, message, data: msgData } = req.body;
    const etabId = req.user.etablissement_id;

    let telephones = [];
    let elevesList = [];

    if (destinataires === 'tous') {
      // Tous les parents de l'établissement
      [elevesList] = await db.query(
        'SELECT nom, prenom, mere_tel, pere_tel FROM eleves WHERE etablissement_id = ? AND statut = "actif"',
        [etabId]
      );
    } else if (destinataires === 'impayes') {
      // Parents avec impayés
      [elevesList] = await db.query(`
        SELECT DISTINCT e.nom, e.prenom, e.mere_tel, e.pere_tel,
               (fc.montant_total - COALESCE(SUM(p.montant),0)) AS reste
        FROM eleves e
        JOIN inscriptions i ON i.eleve_id = e.id
        JOIN annees_scolaires a ON a.id = i.annee_id AND a.active = 1
        JOIN frais_config fc ON fc.etablissement_id = e.etablissement_id
        LEFT JOIN paiements p ON p.inscription_id = i.id AND p.annule = 0
        WHERE e.etablissement_id = ?
        GROUP BY e.id, fc.id
        HAVING reste > 0
      `, [etabId]);
    } else if (Array.isArray(destinataires)) {
      // Liste d'IDs d'élèves spécifiques
      [elevesList] = await db.query(
        `SELECT nom, prenom, mere_tel, pere_tel FROM eleves WHERE id IN (?) AND etablissement_id = ?`,
        [destinataires, etabId]
      );
    }

    const finalData = { ...msgData, message: msgData?.message || message };
    const resultats = await whatsapp.envoyerMessageEnLot(elevesList, type || 'message_libre', () => finalData);

    // Enregistrer dans l'historique des notifications
    await db.query(
      `INSERT INTO notifications (etablissement_id, expediteur_id, type, message, statut, envoye_at)
       VALUES (?, ?, 'whatsapp', ?, 'envoyee', NOW())`,
      [etabId, req.user.id, finalData.message || type]
    );

    res.json({
      success: true,
      message: `Envoi terminé : ${resultats.success} succès, ${resultats.errors} erreurs`,
      data: resultats
    });

  } catch (err) {
    console.error('[COMM] Erreur envoi WhatsApp:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- ENVOYER UN BULLETIN PAR WHATSAPP ----
router.post('/whatsapp/bulletin/:bulletin_id', requireRole('directeur','super_admin'), async (req, res) => {
  try {
    const [[bulletin]] = await db.query(`
      SELECT b.*, CONCAT(e.nom,' ',e.prenom) AS eleve, e.mere_tel, e.pere_tel,
             CONCAT(e.mere_nom) AS parent_nom, c.nom AS classe, p.nom AS trimestre
      FROM bulletins b
      JOIN inscriptions i ON i.id = b.inscription_id
      JOIN eleves e ON e.id = i.eleve_id
      JOIN classes c ON c.id = i.classe_id
      JOIN periodes p ON p.id = b.periode_id
      WHERE b.id = ?
    `, [req.params.bulletin_id]);

    if (!bulletin) return res.status(404).json({ error: 'Bulletin introuvable' });

    const tel = bulletin.mere_tel || bulletin.pere_tel;
    if (!tel) return res.status(400).json({ error: 'Aucun numéro de téléphone parent trouvé' });

    const result = await whatsapp.envoyerMessage(tel, 'bulletin_disponible', {
      parent_nom: bulletin.parent_nom || 'Parent',
      eleve_nom:  bulletin.eleve,
      classe:     bulletin.classe,
      trimestre:  bulletin.trimestre,
      moyenne:    bulletin.moyenne_generale,
      rang:       bulletin.rang,
      effectif:   bulletin.effectif_classe,
      mention:    getMention(bulletin.moyenne_generale),
    });

    res.json({ success: result.success, data: result });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- HISTORIQUE DES NOTIFICATIONS ----
router.get('/historique', async (req, res) => {
  try {
    const [notifs] = await db.query(`
      SELECT n.*, CONCAT(u.nom,' ',u.prenom) AS expediteur
      FROM notifications n
      LEFT JOIN utilisateurs u ON u.id = n.expediteur_id
      WHERE n.etablissement_id = ?
      ORDER BY n.created_at DESC LIMIT 50
    `, [req.user.etablissement_id]);
    res.json({ success: true, data: notifs });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- WEBHOOK WHATSAPP META ----
router.get('/webhook/whatsapp',  whatsapp.verifyWebhook);
router.post('/webhook/whatsapp', async (req, res) => {
  // Traiter les messages entrants (réponses des parents)
  console.log('[WEBHOOK WA] Message reçu:', JSON.stringify(req.body, null, 2));
  res.status(200).json({ received: true });
});

function getMention(note) {
  if (!note) return 'N/A';
  const n = parseFloat(note);
  if (n >= 16) return 'Très Bien';
  if (n >= 14) return 'Bien';
  if (n >= 12) return 'Assez Bien';
  if (n >= 10) return 'Passable';
  return 'Insuffisant';
}

module.exports = router;
