// ============================================================
// ROUTES/AUTH.JS — Authentification sécurisée JWT
// Constellation School — Patrick TALLA — 2025
// ============================================================

const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const db      = require('../config/database');
const router  = express.Router();

// ---- CONNEXION ----
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 6 }),
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ error: 'Données invalides', details: errors.array() });
    }

    const { email, password } = req.body;

    // Chercher l'utilisateur
    const [rows] = await db.query(
      'SELECT * FROM utilisateurs WHERE email = ? AND actif = 1 LIMIT 1',
      [email]
    );

    if (!rows.length) {
      return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
    }

    const user = rows[0];

    // Vérifier si le compte est bloqué
    if (user.bloque) {
      return res.status(403).json({ error: 'Compte bloqué. Contactez l\'administrateur.' });
    }

    // Vérifier le mot de passe
    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
      // Incrémenter les tentatives échouées
      await db.query(
        'UPDATE utilisateurs SET tentatives_echec = tentatives_echec + 1, bloque = IF(tentatives_echec >= 4, 1, 0) WHERE id = ?',
        [user.id]
      );
      return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
    }

    // Réinitialiser les tentatives
    await db.query(
      'UPDATE utilisateurs SET tentatives_echec = 0, derniere_connexion = NOW() WHERE id = ?',
      [user.id]
    );

    // Générer le token JWT
    const token = jwt.sign(
      {
        id:               user.id,
        email:            user.email,
        role:             user.role,
        etablissement_id: user.etablissement_id,
        nom:              user.nom,
        prenom:           user.prenom,
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '24h' }
    );

    res.json({
      success: true,
      token,
      user: {
        id:               user.id,
        nom:              user.nom,
        prenom:           user.prenom,
        email:            user.email,
        role:             user.role,
        etablissement_id: user.etablissement_id,
        photo_url:        user.photo_url,
      }
    });

  } catch (err) {
    console.error('[AUTH] Erreur login:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- DÉCONNEXION ----
router.post('/logout', (req, res) => {
  res.json({ success: true, message: 'Déconnecté avec succès' });
});

// ---- VÉRIFICATION DU TOKEN ----
router.get('/verify', require('../middleware/auth'), (req, res) => {
  res.json({ valid: true, user: req.user });
});

// ---- RÉINITIALISATION MOT DE PASSE ----
router.post('/reset-password', [
  body('email').isEmail().normalizeEmail(),
], async (req, res) => {
  try {
    const { email } = req.body;
    const [rows] = await db.query('SELECT id FROM utilisateurs WHERE email = ?', [email]);
    if (!rows.length) {
      // Ne pas révéler si l'email existe
      return res.json({ success: true, message: 'Si cet email existe, un lien vous a été envoyé.' });
    }
    const token = jwt.sign({ id: rows[0].id, type: 'reset' }, process.env.JWT_SECRET, { expiresIn: '1h' });
    await db.query('UPDATE utilisateurs SET token_reset = ?, token_expiry = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?',
      [token, rows[0].id]);
    // TODO: Envoyer l'email/WhatsApp avec le lien de réinitialisation
    res.json({ success: true, message: 'Lien de réinitialisation envoyé.' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
