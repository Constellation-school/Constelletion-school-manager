// ============================================================
// ROUTES/NOTES.JS — Saisie et calcul des notes
// Constellation School — Patrick TALLA — 2025
// ============================================================

const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const { requireRole } = require('../middleware/auth');
const router  = express.Router();

router.use(auth);

// ---- OBTENIR LES NOTES D'UNE CLASSE / MATIÈRE ----
router.get('/', async (req, res) => {
  try {
    const { classe_id, matiere_id, periode_id } = req.query;
    const etabId = req.user.etablissement_id;

    const [notes] = await db.query(`
      SELECT n.*, e.nom, e.prenom, e.matricule,
             m.nom_fr AS matiere, m.coefficient AS coef_matiere,
             p.nom AS periode
      FROM notes n
      JOIN inscriptions i ON i.id = n.inscription_id
      JOIN eleves e ON e.id = i.eleve_id
      JOIN matieres m ON m.id = n.matiere_id
      JOIN periodes p ON p.id = n.periode_id
      WHERE e.etablissement_id = ?
        AND i.classe_id = ?
        AND n.matiere_id = ?
        AND n.periode_id = ?
      ORDER BY e.nom, e.prenom
    `, [etabId, classe_id, matiere_id, periode_id]);

    res.json({ success: true, data: notes });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- SAISIR / MODIFIER UNE NOTE ----
router.post('/', async (req, res) => {
  try {
    const { inscription_id, matiere_id, periode_id,
            note_devoir1, note_devoir2, note_composition,
            coefficient, note_sur } = req.body;

    // Calcul automatique de la moyenne
    const d1   = parseFloat(note_devoir1)     || 0;
    const d2   = parseFloat(note_devoir2)     || 0;
    const comp = parseFloat(note_composition) || 0;
    const note_finale = ((d1 + d2 + comp * 2) / 4).toFixed(2);

    // Appréciation automatique
    const appreciation = getAppreciation(parseFloat(note_finale));

    // Upsert (insérer ou mettre à jour)
    await db.query(`
      INSERT INTO notes
        (inscription_id, matiere_id, periode_id, enseignant_id,
         note_devoir1, note_devoir2, note_composition, note_finale,
         coefficient, note_sur, appreciation, saisie_validee)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
      ON DUPLICATE KEY UPDATE
        note_devoir1 = VALUES(note_devoir1),
        note_devoir2 = VALUES(note_devoir2),
        note_composition = VALUES(note_composition),
        note_finale = VALUES(note_finale),
        appreciation = VALUES(appreciation),
        saisie_validee = 1,
        updated_at = NOW()
    `, [inscription_id, matiere_id, periode_id, req.user.id,
        d1, d2, comp, note_finale, coefficient || 1, note_sur || 20, appreciation]);

    res.json({
      success: true,
      message: 'Note enregistrée',
      data: { note_finale, appreciation }
    });

  } catch (err) {
    console.error('[NOTES] Erreur POST /:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- SAISIE EN LOT (toute une classe) ----
router.post('/bulk', async (req, res) => {
  try {
    const { notes } = req.body; // Array de notes
    let saved = 0;
    const errors = [];

    for (const note of notes) {
      try {
        const d1   = parseFloat(note.note_devoir1)     || 0;
        const d2   = parseFloat(note.note_devoir2)     || 0;
        const comp = parseFloat(note.note_composition) || 0;
        const note_finale = ((d1 + d2 + comp * 2) / 4).toFixed(2);
        const appreciation = getAppreciation(parseFloat(note_finale));

        await db.query(`
          INSERT INTO notes
            (inscription_id, matiere_id, periode_id, enseignant_id,
             note_devoir1, note_devoir2, note_composition, note_finale,
             coefficient, note_sur, appreciation, saisie_validee)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
          ON DUPLICATE KEY UPDATE
            note_devoir1 = VALUES(note_devoir1),
            note_devoir2 = VALUES(note_devoir2),
            note_composition = VALUES(note_composition),
            note_finale = VALUES(note_finale),
            appreciation = VALUES(appreciation),
            updated_at = NOW()
        `, [note.inscription_id, note.matiere_id, note.periode_id, req.user.id,
            d1, d2, comp, note_finale, note.coefficient || 1, 20, appreciation]);
        saved++;
      } catch (e) {
        errors.push({ inscription_id: note.inscription_id, error: e.message });
      }
    }

    res.json({ success: true, saved, errors, message: `${saved} note(s) enregistrée(s)` });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- CALCUL DES MOYENNES ET CLASSEMENTS ----
router.post('/calculer-moyennes/:periode_id/:classe_id', async (req, res) => {
  try {
    const { periode_id, classe_id } = req.params;
    const etabId = req.user.etablissement_id;

    // Récupérer toutes les inscriptions de la classe
    const [inscriptions] = await db.query(
      'SELECT id, eleve_id FROM inscriptions WHERE classe_id = ?',
      [classe_id]
    );

    const moyennes = [];

    for (const insc of inscriptions) {
      const [notes] = await db.query(`
        SELECT n.note_finale, n.coefficient
        FROM notes n
        WHERE n.inscription_id = ? AND n.periode_id = ? AND n.note_finale IS NOT NULL
      `, [insc.id, periode_id]);

      if (notes.length > 0) {
        const totalPoints = notes.reduce((s, n) => s + (n.note_finale * n.coefficient), 0);
        const totalCoeff  = notes.reduce((s, n) => s + parseFloat(n.coefficient), 0);
        const moyenne     = totalCoeff > 0 ? (totalPoints / totalCoeff).toFixed(2) : 0;
        moyennes.push({ inscription_id: insc.id, moyenne: parseFloat(moyenne) });
      }
    }

    // Calculer les rangs
    moyennes.sort((a, b) => b.moyenne - a.moyenne);
    moyennes.forEach((m, i) => { m.rang = i + 1; });

    // Mettre à jour les bulletins
    for (const m of moyennes) {
      await db.query(`
        INSERT INTO bulletins (inscription_id, periode_id, moyenne_generale,
                               rang, effectif_classe)
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          moyenne_generale = VALUES(moyenne_generale),
          rang = VALUES(rang),
          effectif_classe = VALUES(effectif_classe)
      `, [m.inscription_id, periode_id, m.moyenne, m.rang, inscriptions.length]);
    }

    const moyenneClasse = moyennes.length > 0
      ? (moyennes.reduce((s, m) => s + m.moyenne, 0) / moyennes.length).toFixed(2)
      : 0;

    res.json({
      success: true,
      message: `${moyennes.length} moyenne(s) calculée(s)`,
      data: { moyennes, moyenne_classe: moyenneClasse }
    });

  } catch (err) {
    console.error('[NOTES] Erreur calcul moyennes:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- HELPER : Appréciation automatique ----
function getAppreciation(note) {
  if (note >= 18) return 'Excellent';
  if (note >= 16) return 'Très Bien';
  if (note >= 14) return 'Bien';
  if (note >= 12) return 'Assez Bien';
  if (note >= 10) return 'Passable';
  if (note >= 8)  return 'Insuffisant';
  if (note >= 5)  return 'Médiocre';
  return 'Très Faible';
}

module.exports = router;
