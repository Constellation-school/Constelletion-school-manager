// ============================================================
// ROUTES/PAIEMENTS.JS — Gestion des paiements scolaires
// Constellation School — Patrick TALLA — 2025
// ============================================================

const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const { requireRole } = require('../middleware/auth');
const router  = express.Router();

router.use(auth);

// ---- LISTE DES PAIEMENTS ----
router.get('/', async (req, res) => {
  try {
    const { classe_id, statut, eleve_id, date_debut, date_fin } = req.query;
    const etabId = req.user.etablissement_id;

    let query = `
      SELECT p.*, CONCAT(e.nom,' ',e.prenom) AS eleve,
             e.matricule, c.nom AS classe,
             fc.libelle AS frais_libelle, fc.montant_total,
             CONCAT(u.nom,' ',u.prenom) AS caissier
      FROM paiements p
      JOIN inscriptions i  ON i.id = p.inscription_id
      JOIN eleves e        ON e.id = i.eleve_id
      JOIN classes c       ON c.id = i.classe_id
      JOIN frais_config fc ON fc.id = p.frais_id
      JOIN utilisateurs u  ON u.id = p.caissier_id
      WHERE p.etablissement_id = ? AND p.annule = 0
    `;
    const params = [etabId];

    if (classe_id)  { query += ' AND i.classe_id = ?';     params.push(classe_id);  }
    if (eleve_id)   { query += ' AND e.id = ?';            params.push(eleve_id);   }
    if (date_debut) { query += ' AND p.date_paiement >= ?'; params.push(date_debut); }
    if (date_fin)   { query += ' AND p.date_paiement <= ?'; params.push(date_fin);   }

    query += ' ORDER BY p.created_at DESC';

    const [paiements] = await db.query(query, params);
    res.json({ success: true, data: paiements, count: paiements.length });
  } catch (err) {
    console.error('[PAIEMENTS] Erreur GET /:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- SITUATION FINANCIÈRE D'UN ÉLÈVE ----
router.get('/situation/:inscription_id', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT fc.id AS frais_id, fc.libelle, fc.montant_total,
             fc.nb_tranches, fc.type,
             COALESCE(SUM(p.montant),0) AS total_paye,
             (fc.montant_total - COALESCE(SUM(p.montant),0)) AS reste_a_payer
      FROM frais_config fc
      LEFT JOIN paiements p ON p.frais_id = fc.id
                            AND p.inscription_id = ?
                            AND p.annule = 0
      WHERE fc.etablissement_id = ?
      GROUP BY fc.id
    `, [req.params.inscription_id, req.user.etablissement_id]);

    const totalDu    = rows.reduce((s, r) => s + parseFloat(r.montant_total), 0);
    const totalPaye  = rows.reduce((s, r) => s + parseFloat(r.total_paye), 0);
    const totalReste = totalDu - totalPaye;
    const taux       = totalDu > 0 ? Math.round((totalPaye / totalDu) * 100) : 0;

    res.json({
      success: true,
      data: {
        frais: rows,
        total_du:    totalDu,
        total_paye:  totalPaye,
        total_reste: totalReste,
        taux_paiement: taux,
        solde_ok: totalReste <= 0
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- ENREGISTRER UN PAIEMENT ----
router.post('/', requireRole('directeur', 'comptable', 'super_admin'), async (req, res) => {
  try {
    const {
      inscription_id, frais_id, montant, tranche,
      mode_paiement, reference_paiement, observations
    } = req.body;

    if (!inscription_id || !frais_id || !montant) {
      return res.status(400).json({ error: 'inscription_id, frais_id et montant sont requis' });
    }

    const etabId = req.user.etablissement_id;

    // Générer le numéro de reçu unique
    const year    = new Date().getFullYear();
    const [[cnt]] = await db.query(
      'SELECT COUNT(*) AS total FROM paiements WHERE etablissement_id = ?', [etabId]
    );
    const numero_recu = `CSY-${year}-${String(cnt.total + 1).padStart(6, '0')}`;

    // Insérer le paiement
    const [result] = await db.query(`
      INSERT INTO paiements
        (etablissement_id, inscription_id, frais_id, numero_recu,
         montant, tranche, mode_paiement, reference_paiement,
         date_paiement, caissier_id, observations)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?)
    `, [etabId, inscription_id, frais_id, numero_recu,
        montant, tranche || 1, mode_paiement || 'especes',
        reference_paiement, req.user.id, observations]);

    // Récupérer les infos pour le reçu
    const [[infoEleve]] = await db.query(`
      SELECT CONCAT(e.nom,' ',e.prenom) AS eleve, e.matricule,
             c.nom AS classe, a.libelle AS annee,
             et.nom AS ecole, fc.libelle AS frais_libelle
      FROM inscriptions i
      JOIN eleves e ON e.id = i.eleve_id
      JOIN classes c ON c.id = i.classe_id
      JOIN annees_scolaires a ON a.id = i.annee_id
      JOIN etablissements et ON et.id = e.etablissement_id
      JOIN frais_config fc ON fc.id = ?
      WHERE i.id = ?
    `, [frais_id, inscription_id]);

    res.status(201).json({
      success: true,
      message: 'Paiement enregistré avec succès',
      data: {
        id:           result.insertId,
        numero_recu,
        montant,
        mode_paiement,
        date_paiement: new Date().toISOString().split('T')[0],
        ...infoEleve
      }
    });

  } catch (err) {
    console.error('[PAIEMENTS] Erreur POST /:', err);
    if (err.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ error: 'Ce reçu existe déjà' });
    }
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- ANNULER UN PAIEMENT ----
router.patch('/:id/annuler', requireRole('directeur', 'super_admin'), async (req, res) => {
  try {
    await db.query(
      'UPDATE paiements SET annule = 1, annule_at = NOW(), annule_par = ? WHERE id = ? AND etablissement_id = ?',
      [req.user.id, req.params.id, req.user.etablissement_id]
    );
    res.json({ success: true, message: 'Paiement annulé. Opération tracée dans le journal.' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- RAPPORT FINANCIER ----
router.get('/rapport/mensuel', async (req, res) => {
  try {
    const { annee, mois } = req.query;
    const etabId = req.user.etablissement_id;

    const [rows] = await db.query(`
      SELECT
        DATE_FORMAT(date_paiement, '%Y-%m') AS mois,
        mode_paiement,
        COUNT(*)                            AS nb_paiements,
        SUM(montant)                        AS total_encaisse
      FROM paiements
      WHERE etablissement_id = ? AND annule = 0
        ${annee ? `AND YEAR(date_paiement) = ${parseInt(annee)}` : ''}
        ${mois  ? `AND MONTH(date_paiement) = ${parseInt(mois)}`  : ''}
      GROUP BY mois, mode_paiement
      ORDER BY mois DESC
    `, [etabId]);

    const [[impayeStats]] = await db.query(`
      SELECT COUNT(DISTINCT i.eleve_id) AS nb_impaye,
             SUM(fc.montant_total - COALESCE(paie.total,0)) AS montant_impaye
      FROM inscriptions i
      JOIN frais_config fc ON fc.etablissement_id = i.etablissement_id
      LEFT JOIN (
        SELECT inscription_id, SUM(montant) AS total
        FROM paiements WHERE annule = 0
        GROUP BY inscription_id
      ) paie ON paie.inscription_id = i.id
      WHERE i.etablissement_id = ?
        AND (fc.montant_total - COALESCE(paie.total,0)) > 0
    `, [etabId]);

    res.json({ success: true, data: { paiements: rows, impayes: impayeStats } });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- WEBHOOK MONETBIL (paiement mobile confirmé) ----
router.post('/webhook/monetbil', async (req, res) => {
  try {
    const { status, amount, transaction_id, phone, service_id } = req.body;
    console.log('[MONETBIL WEBHOOK]', { status, amount, transaction_id });

    if (status !== 'success') {
      return res.status(200).json({ received: true });
    }

    // Trouver l'inscription associée via la session de paiement
    const [[session]] = await db.query(
      'SELECT * FROM paiements WHERE reference_paiement = ? LIMIT 1',
      [`PENDING-${transaction_id}`]
    );

    if (session) {
      await db.query(
        'UPDATE paiements SET reference_paiement = ?, mode_paiement = "mobile_money" WHERE id = ?',
        [transaction_id, session.id]
      );
    }

    res.status(200).json({ received: true, status: 'processed' });
  } catch (err) {
    console.error('[WEBHOOK MONETBIL] Erreur:', err);
    res.status(200).json({ received: true });
  }
});

// ---- LISTE DES IMPAYÉS ----
router.get('/impayes/liste', async (req, res) => {
  try {
    const etabId = req.user.etablissement_id;
    const [rows] = await db.query(`
      SELECT e.id AS eleve_id, CONCAT(e.nom,' ',e.prenom) AS eleve,
             e.matricule, e.mere_tel, e.pere_tel,
             c.nom AS classe, fc.libelle AS frais,
             fc.montant_total, COALESCE(SUM(p.montant),0) AS total_paye,
             (fc.montant_total - COALESCE(SUM(p.montant),0)) AS reste
      FROM eleves e
      JOIN inscriptions i ON i.eleve_id = e.id
      JOIN classes c ON c.id = i.classe_id
      JOIN annees_scolaires a ON a.id = i.annee_id AND a.active = 1
      JOIN frais_config fc ON fc.etablissement_id = e.etablissement_id AND fc.annee_id = i.annee_id
      LEFT JOIN paiements p ON p.inscription_id = i.id AND p.frais_id = fc.id AND p.annule = 0
      WHERE e.etablissement_id = ?
      GROUP BY e.id, fc.id
      HAVING reste > 0
      ORDER BY reste DESC
    `, [etabId]);

    res.json({ success: true, data: rows, count: rows.length });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
