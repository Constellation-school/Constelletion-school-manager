// ============================================================
// ROUTES/ELEVES.JS — Gestion des élèves
// Constellation School — Patrick TALLA — 2025
// ============================================================

const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const { requireRole } = require('../middleware/auth');
const router  = express.Router();

// Toutes les routes nécessitent une authentification
router.use(auth);

// ---- LISTE DES ÉLÈVES ----
router.get('/', async (req, res) => {
  try {
    const { classe_id, annee_id, statut, search } = req.query;
    const etabId = req.user.etablissement_id;

    let query = `
      SELECT e.*, i.classe_id, c.nom AS classe_nom, i.id AS inscription_id,
             a.libelle AS annee_scolaire
      FROM eleves e
      LEFT JOIN inscriptions i ON i.eleve_id = e.id
      LEFT JOIN classes c ON c.id = i.classe_id
      LEFT JOIN annees_scolaires a ON a.id = i.annee_id AND a.active = 1
      WHERE e.etablissement_id = ?
    `;
    const params = [etabId];

    if (classe_id) { query += ' AND i.classe_id = ?'; params.push(classe_id); }
    if (statut)    { query += ' AND e.statut = ?';    params.push(statut); }
    if (search)    {
      query += ' AND (e.nom LIKE ? OR e.prenom LIKE ? OR e.matricule LIKE ?)';
      const s = `%${search}%`;
      params.push(s, s, s);
    }

    query += ' ORDER BY e.nom, e.prenom';

    const [eleves] = await db.query(query, params);

    // En-tête pour le cache PWA
    res.setHeader('Cache-Control', 'private, max-age=300');
    res.json({ success: true, data: eleves, count: eleves.length });

  } catch (err) {
    console.error('[ELEVES] Erreur GET /:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- DÉTAIL D'UN ÉLÈVE ----
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT e.*, i.classe_id, c.nom AS classe_nom, i.decision_fin,
              i.rang_final, i.moyenne_annuelle
       FROM eleves e
       LEFT JOIN inscriptions i ON i.eleve_id = e.id
       LEFT JOIN classes c ON c.id = i.classe_id
       LEFT JOIN annees_scolaires a ON a.id = i.annee_id AND a.active = 1
       WHERE e.id = ? AND e.etablissement_id = ?`,
      [req.params.id, req.user.etablissement_id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Élève introuvable' });
    res.json({ success: true, data: rows[0] });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- CRÉER UN ÉLÈVE ----
router.post('/', requireRole('directeur', 'censeur', 'super_admin'), async (req, res) => {
  try {
    const etabId = req.user.etablissement_id;
    const { nom, prenom, date_naissance, sexe, classe_id, ...rest } = req.body;

    if (!nom || !prenom || !sexe) {
      return res.status(400).json({ error: 'Nom, prénom et sexe sont obligatoires' });
    }

    // Générer le matricule automatiquement
    const year = new Date().getFullYear();
    const [countRows] = await db.query(
      'SELECT COUNT(*) as total FROM eleves WHERE etablissement_id = ?', [etabId]
    );
    const total = countRows[0].total + 1;
    const matricule = `CSY-${year}-${String(total).padStart(4, '0')}`;

    const [result] = await db.query(
      `INSERT INTO eleves (etablissement_id, matricule, nom, prenom, date_naissance,
                           sexe, adresse, pere_nom, pere_tel, mere_nom, mere_tel,
                           tuteur_nom, tuteur_tel, statut)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'actif')`,
      [etabId, matricule, nom.toUpperCase(), prenom, rest.date_naissance,
       sexe, rest.adresse, rest.pere_nom, rest.pere_tel,
       rest.mere_nom, rest.mere_tel, rest.tuteur_nom, rest.tuteur_tel]
    );

    const eleveId = result.insertId;

    // Créer l'inscription si une classe est fournie
    if (classe_id) {
      const [anneeRows] = await db.query(
        'SELECT id FROM annees_scolaires WHERE etablissement_id = ? AND active = 1 LIMIT 1',
        [etabId]
      );
      if (anneeRows.length) {
        await db.query(
          `INSERT INTO inscriptions (eleve_id, classe_id, annee_id, etablissement_id,
                                     date_inscription, type)
           VALUES (?, ?, ?, ?, CURDATE(), 'nouvelle')`,
          [eleveId, classe_id, anneeRows[0].id, etabId]
        );
      }
    }

    res.status(201).json({
      success: true,
      message: 'Élève créé avec succès',
      data: { id: eleveId, matricule }
    });

  } catch (err) {
    console.error('[ELEVES] Erreur POST /:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- MODIFIER UN ÉLÈVE ----
router.put('/:id', requireRole('directeur', 'censeur', 'super_admin'), async (req, res) => {
  try {
    const { nom, prenom, date_naissance, sexe, adresse,
            pere_nom, pere_tel, mere_nom, mere_tel } = req.body;

    await db.query(
      `UPDATE eleves SET nom=?, prenom=?, date_naissance=?, sexe=?, adresse=?,
                        pere_nom=?, pere_tel=?, mere_nom=?, mere_tel=?,
                        updated_at=NOW()
       WHERE id = ? AND etablissement_id = ?`,
      [nom?.toUpperCase(), prenom, date_naissance, sexe, adresse,
       pere_nom, pere_tel, mere_nom, mere_tel,
       req.params.id, req.user.etablissement_id]
    );
    res.json({ success: true, message: 'Élève mis à jour' });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- STATISTIQUES DES ÉLÈVES (pour le dashboard) ----
router.get('/stats/summary', async (req, res) => {
  try {
    const etabId = req.user.etablissement_id;
    const [[stats]] = await db.query(`
      SELECT
        COUNT(*) AS total,
        SUM(sexe = 'F') AS filles,
        SUM(sexe = 'M') AS garcons,
        SUM(statut = 'actif') AS actifs,
        SUM(statut = 'transfere') AS transferes
      FROM eleves WHERE etablissement_id = ?
    `, [etabId]);
    res.json({ success: true, data: stats });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
