// routes/personnel.js
const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const router  = express.Router();
router.use(auth);

router.get('/', async (req, res) => {
  try {
    const [pers] = await db.query(`
      SELECT u.id, u.nom, u.prenom, u.email, u.telephone, u.role,
             p.grade, p.specialite, p.diplome_plus_haut, p.type_contrat,
             p.salaire_base, p.date_embauche
      FROM utilisateurs u
      LEFT JOIN personnel p ON p.utilisateur_id = u.id
      WHERE u.etablissement_id = ? AND u.actif = 1
        AND u.role IN ('enseignant','censeur','surveillant','comptable')
      ORDER BY u.nom, u.prenom
    `, [req.user.etablissement_id]);
    res.json({ success: true, data: pers });
  } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

router.get('/salaires/:mois/:annee', async (req, res) => {
  try {
    const [salaires] = await db.query(`
      SELECT s.*, CONCAT(u.nom,' ',u.prenom) AS employe, u.role
      FROM salaires s
      JOIN personnel p ON p.id = s.personnel_id
      JOIN utilisateurs u ON u.id = p.utilisateur_id
      WHERE u.etablissement_id = ? AND s.mois = ? AND s.annee = ?
      ORDER BY u.nom
    `, [req.user.etablissement_id, req.params.mois, req.params.annee]);
    res.json({ success: true, data: salaires });
  } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

module.exports = router;
