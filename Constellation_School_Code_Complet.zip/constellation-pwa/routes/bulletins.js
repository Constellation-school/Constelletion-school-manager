// routes/bulletins.js
const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const router  = express.Router();
router.use(auth);

router.get('/', async (req, res) => {
  try {
    const { classe_id, periode_id } = req.query;
    const [bulletins] = await db.query(`
      SELECT b.*, CONCAT(e.nom,' ',e.prenom) AS eleve, e.matricule,
             c.nom AS classe, p.nom AS periode
      FROM bulletins b
      JOIN inscriptions i ON i.id = b.inscription_id
      JOIN eleves e ON e.id = i.eleve_id
      JOIN classes c ON c.id = i.classe_id
      JOIN periodes p ON p.id = b.periode_id
      WHERE c.etablissement_id = ?
        ${classe_id  ? `AND c.id = ${parseInt(classe_id)}` : ''}
        ${periode_id ? `AND p.id = ${parseInt(periode_id)}` : ''}
      ORDER BY b.rang
    `, [req.user.etablissement_id]);
    res.json({ success: true, data: bulletins });
  } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

router.post('/generer/:inscription_id/:periode_id', async (req, res) => {
  const { inscription_id, periode_id } = req.params;
  try {
    const [[b]] = await db.query('SELECT * FROM bulletins WHERE inscription_id=? AND periode_id=?', [inscription_id, periode_id]);
    if (!b) return res.status(404).json({ error: 'Bulletin introuvable. Calculez les moyennes d\'abord.' });
    await db.query('UPDATE bulletins SET genere=1, genere_at=NOW() WHERE inscription_id=? AND periode_id=?', [inscription_id, periode_id]);
    res.json({ success: true, message: 'Bulletin généré', data: b });
  } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});
module.exports = router;
