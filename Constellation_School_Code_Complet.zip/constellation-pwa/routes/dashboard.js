// ============================================================
// ROUTES/DASHBOARD.JS — Statistiques tableau de bord
// Constellation School — Patrick TALLA — 2025
// ============================================================

const express = require('express');
const db      = require('../config/database');
const auth    = require('../middleware/auth');
const router  = express.Router();

router.use(auth);

// ---- STATISTIQUES PRINCIPALES ----
router.get('/stats', async (req, res) => {
  try {
    const etabId = req.user.etablissement_id;

    // Lancer toutes les requêtes en parallèle pour la performance
    const [
      [elevesStats],
      [financeStats],
      [personnelStats],
      [classesStats],
      [absencesAujourdhui],
      [topClasses],
      [impayes],
    ] = await Promise.all([
      // Statistiques élèves
      db.query(`
        SELECT COUNT(*) AS total,
               SUM(sexe='F') AS filles,
               SUM(sexe='M') AS garcons,
               SUM(statut='actif') AS actifs
        FROM eleves WHERE etablissement_id = ?
      `, [etabId]),

      // Statistiques financières du mois en cours
      db.query(`
        SELECT
          COALESCE(SUM(p.montant),0)              AS encaisse_mois,
          COUNT(p.id)                             AS nb_paiements_mois,
          (SELECT COALESCE(SUM(montant),0) FROM paiements
           WHERE etablissement_id = ? AND annule = 0
           AND YEAR(date_paiement) = YEAR(CURDATE())) AS encaisse_annee
        FROM paiements p
        WHERE p.etablissement_id = ?
          AND p.annule = 0
          AND MONTH(p.date_paiement) = MONTH(CURDATE())
          AND YEAR(p.date_paiement) = YEAR(CURDATE())
      `, [etabId, etabId]),

      // Statistiques personnel
      db.query(`
        SELECT COUNT(*) AS total,
               SUM(role='enseignant') AS enseignants,
               SUM(role='comptable') AS comptables,
               SUM(role='censeur') AS censeurs
        FROM utilisateurs
        WHERE etablissement_id = ? AND actif = 1
      `, [etabId]),

      // Nombre de classes
      db.query(`
        SELECT COUNT(*) AS total
        FROM classes c
        JOIN annees_scolaires a ON a.id = c.annee_id AND a.active = 1
        WHERE c.etablissement_id = ?
      `, [etabId]),

      // Absences du jour
      db.query(`
        SELECT COUNT(*) AS total,
               SUM(justifiee=0) AS injustifiees,
               SUM(justifiee=1) AS justifiees
        FROM presences_eleves pe
        JOIN inscriptions i ON i.id = pe.inscription_id
        JOIN eleves e ON e.id = i.eleve_id
        WHERE e.etablissement_id = ? AND pe.date_absence = CURDATE()
      `, [etabId]),

      // Top 5 classes par moyenne
      db.query(`
        SELECT c.nom AS classe,
               ROUND(AVG(b.moyenne_generale),2) AS moyenne,
               COUNT(DISTINCT i.eleve_id) AS effectif
        FROM bulletins b
        JOIN inscriptions i ON i.id = b.inscription_id
        JOIN classes c ON c.id = i.classe_id
        JOIN periodes p ON p.id = b.periode_id
        WHERE c.etablissement_id = ? AND p.numero = (
          SELECT MAX(numero) FROM periodes WHERE etablissement_id = ?
        )
        GROUP BY c.id
        ORDER BY moyenne DESC
        LIMIT 5
      `, [etabId, etabId]),

      // Résumé impayés
      db.query(`
        SELECT COUNT(DISTINCT e.id) AS nb_eleves_debiteurs,
               COALESCE(SUM(fc.montant_total - COALESCE(paie.total,0)),0) AS total_impayes
        FROM eleves e
        JOIN inscriptions i ON i.eleve_id = e.id
        JOIN annees_scolaires a ON a.id = i.annee_id AND a.active = 1
        JOIN frais_config fc ON fc.etablissement_id = e.etablissement_id AND fc.annee_id = i.annee_id
        LEFT JOIN (
          SELECT inscription_id, SUM(montant) AS total FROM paiements
          WHERE annule = 0 GROUP BY inscription_id
        ) paie ON paie.inscription_id = i.id
        WHERE e.etablissement_id = ?
          AND (fc.montant_total - COALESCE(paie.total,0)) > 0
      `, [etabId]),
    ]);

    // Taux de recouvrement global
    const [[recouvrement]] = await db.query(`
      SELECT
        COALESCE(SUM(fc.montant_total),0) AS total_attendu,
        COALESCE(SUM(paie.total),0)       AS total_encaisse
      FROM inscriptions i
      JOIN annees_scolaires a ON a.id = i.annee_id AND a.active = 1
      JOIN frais_config fc ON fc.etablissement_id = i.etablissement_id AND fc.annee_id = i.annee_id
      LEFT JOIN (
        SELECT inscription_id, SUM(montant) AS total FROM paiements
        WHERE annule = 0 GROUP BY inscription_id
      ) paie ON paie.inscription_id = i.id
      WHERE i.etablissement_id = ?
    `, [etabId]);

    const taux = recouvrement.total_attendu > 0
      ? Math.round((recouvrement.total_encaisse / recouvrement.total_attendu) * 100)
      : 0;

    // En-tête cache (5 minutes)
    res.setHeader('Cache-Control', 'private, max-age=300');

    res.json({
      success: true,
      data: {
        eleves:      elevesStats[0]     || {},
        finances:    { ...financeStats[0], taux_recouvrement: taux } || {},
        personnel:   personnelStats[0]  || {},
        classes:     classesStats[0]    || {},
        absences:    absencesAujourdhui[0] || {},
        top_classes: topClasses         || [],
        impayes:     impayes[0]         || {},
      },
      generated_at: new Date().toISOString()
    });

  } catch (err) {
    console.error('[DASHBOARD] Erreur:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- ACTIVITÉ RÉCENTE ----
router.get('/activite', async (req, res) => {
  try {
    const etabId = req.user.etablissement_id;
    const [logs] = await db.query(`
      SELECT al.action, al.table_ciblee, al.created_at,
             CONCAT(u.nom,' ',u.prenom) AS utilisateur, u.role
      FROM audit_logs al
      JOIN utilisateurs u ON u.id = al.utilisateur_id
      WHERE al.etablissement_id = ?
      ORDER BY al.created_at DESC
      LIMIT 20
    `, [etabId]);
    res.json({ success: true, data: logs });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ---- ALERTES DU JOUR ----
router.get('/alertes', async (req, res) => {
  try {
    const etabId = req.user.etablissement_id;
    const alertes = [];

    // Élèves avec impayés
    const [[impayes]] = await db.query(
      'SELECT COUNT(DISTINCT e.id) AS n FROM eleves e JOIN inscriptions i ON i.eleve_id=e.id JOIN frais_config fc ON fc.etablissement_id=e.etablissement_id LEFT JOIN paiements p ON p.inscription_id=i.id AND p.annule=0 WHERE e.etablissement_id=? GROUP BY e.etablissement_id HAVING SUM(fc.montant_total) > COALESCE(SUM(p.montant),0)',
      [etabId]
    ).catch(() => [[{ n: 0 }]]);

    if (impayes?.n > 0) {
      alertes.push({
        type: 'danger',
        icon: '💸',
        message: `${impayes.n} élève(s) avec des impayés ce trimestre`,
        action: '/paiements/impayes'
      });
    }

    // Bulletins non générés
    const [[bulletins]] = await db.query(`
      SELECT COUNT(*) AS n FROM inscriptions i
      JOIN annees_scolaires a ON a.id = i.annee_id AND a.active = 1
      LEFT JOIN bulletins b ON b.inscription_id = i.id AND b.genere = 1
      WHERE i.etablissement_id = ? AND b.id IS NULL
    `, [etabId]);

    if (bulletins.n > 0) {
      alertes.push({
        type: 'warning',
        icon: '📋',
        message: `${bulletins.n} bulletin(s) non encore généré(s)`,
        action: '/bulletins'
      });
    }

    // Absences du jour non justifiées
    const [[abs]] = await db.query(`
      SELECT COUNT(*) AS n FROM presences_eleves pe
      JOIN inscriptions i ON i.id = pe.inscription_id
      JOIN eleves e ON e.id = i.eleve_id
      WHERE e.etablissement_id = ? AND pe.date_absence = CURDATE() AND pe.justifiee = 0
    `, [etabId]);

    if (abs.n > 0) {
      alertes.push({
        type: 'info',
        icon: '⚠️',
        message: `${abs.n} absence(s) injustifiée(s) aujourd'hui`,
        action: '/presences'
      });
    }

    res.json({ success: true, data: alertes, count: alertes.length });
  } catch (err) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
