// ============================================================
// OFFLINE-DB.JS — Gestionnaire IndexedDB
// Base de données locale pour Constellation School
// Stocke les données critiques pour le mode hors ligne
// Patrick TALLA — Yaoundé, Cameroun — 2025
// ============================================================

const DB_NAME    = 'ConstellationDB';
const DB_VERSION = 1;

// ---- INITIALISATION DE LA BASE ----
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      console.log('[IDB] Création/migration de la base de données...');

      // ---- TABLE : ÉLÈVES ----
      if (!db.objectStoreNames.contains('eleves')) {
        const eleves = db.createObjectStore('eleves', { keyPath: 'id' });
        eleves.createIndex('classe_id',       'classe_id',       { unique: false });
        eleves.createIndex('nom',             'nom',             { unique: false });
        eleves.createIndex('matricule',       'matricule',       { unique: true  });
        eleves.createIndex('etablissement_id','etablissement_id',{ unique: false });
        console.log('[IDB] Store "eleves" créé ✓');
      }

      // ---- TABLE : CLASSES ----
      if (!db.objectStoreNames.contains('classes')) {
        const classes = db.createObjectStore('classes', { keyPath: 'id' });
        classes.createIndex('annee_id',  'annee_id',  { unique: false });
        classes.createIndex('niveau_id', 'niveau_id', { unique: false });
        console.log('[IDB] Store "classes" créé ✓');
      }

      // ---- TABLE : MATIÈRES ----
      if (!db.objectStoreNames.contains('matieres')) {
        db.createObjectStore('matieres', { keyPath: 'id' });
        console.log('[IDB] Store "matieres" créé ✓');
      }

      // ---- TABLE : NOTES EN ATTENTE (saisies hors ligne) ----
      if (!db.objectStoreNames.contains('notes_offline')) {
        const notes = db.createObjectStore('notes_offline', {
          keyPath: 'id', autoIncrement: true
        });
        notes.createIndex('inscription_id', 'inscription_id', { unique: false });
        notes.createIndex('synced',         'synced',         { unique: false });
        console.log('[IDB] Store "notes_offline" créé ✓');
      }

      // ---- TABLE : PAIEMENTS EN ATTENTE ----
      if (!db.objectStoreNames.contains('paiements_offline')) {
        const paie = db.createObjectStore('paiements_offline', {
          keyPath: 'id', autoIncrement: true
        });
        paie.createIndex('eleve_id', 'eleve_id', { unique: false });
        paie.createIndex('synced',   'synced',   { unique: false });
        console.log('[IDB] Store "paiements_offline" créé ✓');
      }

      // ---- TABLE : EMPLOIS DU TEMPS ----
      if (!db.objectStoreNames.contains('emplois_du_temps')) {
        const edt = db.createObjectStore('emplois_du_temps', { keyPath: 'id' });
        edt.createIndex('classe_id', 'classe_id', { unique: false });
        console.log('[IDB] Store "emplois_du_temps" créé ✓');
      }

      // ---- TABLE : SESSIONS UTILISATEUR ----
      if (!db.objectStoreNames.contains('session')) {
        db.createObjectStore('session', { keyPath: 'key' });
        console.log('[IDB] Store "session" créé ✓');
      }

      // ---- TABLE : ACTIONS EN ATTENTE DE SYNC ----
      if (!db.objectStoreNames.contains('pending_actions')) {
        const pending = db.createObjectStore('pending_actions', {
          keyPath: 'id', autoIncrement: true
        });
        pending.createIndex('type',      'type',      { unique: false });
        pending.createIndex('created_at','created_at',{ unique: false });
        console.log('[IDB] Store "pending_actions" créé ✓');
      }
    };

    request.onsuccess = () => {
      console.log('[IDB] Base de données ouverte ✓');
      resolve(request.result);
    };
    request.onerror = () => {
      console.error('[IDB] Erreur ouverture:', request.error);
      reject(request.error);
    };
  });
}

// ============================================================
// HELPERS GÉNÉRIQUES
// ============================================================

async function dbGet(storeName, key) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const req = db.transaction(storeName, 'readonly')
                  .objectStore(storeName).get(key);
    req.onsuccess = () => res(req.result);
    req.onerror   = () => rej(req.error);
  });
}

async function dbGetAll(storeName, indexName = null, value = null) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const store = db.transaction(storeName, 'readonly').objectStore(storeName);
    const req = indexName ? store.index(indexName).getAll(value) : store.getAll();
    req.onsuccess = () => res(req.result || []);
    req.onerror   = () => rej(req.error);
  });
}

async function dbPut(storeName, data) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const req = db.transaction(storeName, 'readwrite')
                  .objectStore(storeName).put(data);
    req.onsuccess = () => res(req.result);
    req.onerror   = () => rej(req.error);
  });
}

async function dbAdd(storeName, data) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const req = db.transaction(storeName, 'readwrite')
                  .objectStore(storeName).add(data);
    req.onsuccess = () => res(req.result);
    req.onerror   = () => rej(req.error);
  });
}

async function dbDelete(storeName, key) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const req = db.transaction(storeName, 'readwrite')
                  .objectStore(storeName).delete(key);
    req.onsuccess = () => res();
    req.onerror   = () => rej(req.error);
  });
}

async function dbCount(storeName) {
  const db = await openDB();
  return new Promise((res, rej) => {
    const req = db.transaction(storeName, 'readonly')
                  .objectStore(storeName).count();
    req.onsuccess = () => res(req.result);
    req.onerror   = () => rej(req.error);
  });
}

// ============================================================
// GESTION DES ÉLÈVES
// ============================================================

export async function cacheEleves(eleves) {
  console.log(`[IDB] Mise en cache de ${eleves.length} élève(s)...`);
  for (const eleve of eleves) {
    await dbPut('eleves', { ...eleve, cached_at: new Date().toISOString() });
  }
  console.log('[IDB] Élèves mis en cache ✓');
}

export async function getElevesOffline(classeId = null) {
  if (classeId) {
    return dbGetAll('eleves', 'classe_id', classeId);
  }
  return dbGetAll('eleves');
}

export async function getEleveOffline(eleveId) {
  return dbGet('eleves', eleveId);
}

export async function searchElevesOffline(query) {
  const tous = await dbGetAll('eleves');
  const q = query.toLowerCase();
  return tous.filter(e =>
    e.nom.toLowerCase().includes(q) ||
    e.prenom.toLowerCase().includes(q) ||
    (e.matricule && e.matricule.toLowerCase().includes(q))
  );
}

// ============================================================
// GESTION DES CLASSES
// ============================================================

export async function cacheClasses(classes) {
  for (const c of classes) await dbPut('classes', c);
  console.log('[IDB] Classes mises en cache ✓');
}

export async function getClassesOffline() {
  return dbGetAll('classes');
}

// ============================================================
// GESTION DES MATIÈRES
// ============================================================

export async function cacheMatieres(matieres) {
  for (const m of matieres) await dbPut('matieres', m);
  console.log('[IDB] Matières mises en cache ✓');
}

export async function getMatieresOffline() {
  return dbGetAll('matieres');
}

// ============================================================
// GESTION DES NOTES HORS LIGNE
// ============================================================

export async function saveNoteOffline(noteData, userToken) {
  const note = {
    data: noteData,
    token: userToken,
    synced: false,
    created_offline_at: new Date().toISOString(),
    type: 'note'
  };
  const id = await dbAdd('notes_offline', note);
  // Enregistrer dans la file d'attente de synchronisation
  await addPendingAction({
    type: 'sync-notes',
    store: 'notes_offline',
    record_id: id,
    url: '/api/notes',
    method: 'POST',
    body: JSON.stringify(noteData),
    created_at: new Date().toISOString()
  });
  console.log(`[IDB] Note sauvegardée hors ligne (id: ${id}) ✓`);
  return id;
}

export async function getNotesOffline() {
  return dbGetAll('notes_offline', 'synced', false);
}

export async function markNoteAsSynced(id) {
  const db = await openDB();
  const tx = db.transaction('notes_offline', 'readwrite');
  const store = tx.objectStore('notes_offline');
  const note = await new Promise((res, rej) => {
    const req = store.get(id);
    req.onsuccess = () => res(req.result);
    req.onerror   = () => rej(req.error);
  });
  if (note) {
    note.synced = true;
    note.synced_at = new Date().toISOString();
    store.put(note);
  }
}

// ============================================================
// GESTION DES PAIEMENTS HORS LIGNE
// ============================================================

export async function savePaiementOffline(paiementData, userToken) {
  const paiement = {
    data: paiementData,
    token: userToken,
    synced: false,
    created_offline_at: new Date().toISOString(),
    type: 'paiement'
  };
  const id = await dbAdd('paiements_offline', paiement);
  await addPendingAction({
    type: 'sync-paiements',
    store: 'paiements_offline',
    record_id: id,
    url: '/api/paiements',
    method: 'POST',
    body: JSON.stringify(paiementData),
    created_at: new Date().toISOString()
  });
  console.log(`[IDB] Paiement sauvegardé hors ligne (id: ${id}) ✓`);
  return id;
}

export async function getPaiementsOffline() {
  return dbGetAll('paiements_offline', 'synced', false);
}

// ============================================================
// FILE D'ATTENTE DE SYNCHRONISATION
// ============================================================

async function addPendingAction(action) {
  return dbAdd('pending_actions', action);
}

export async function getPendingActions() {
  return dbGetAll('pending_actions');
}

export async function countPendingActions() {
  return dbCount('pending_actions');
}

export async function deletePendingAction(id) {
  return dbDelete('pending_actions', id);
}

export async function clearSyncedActions() {
  const all = await dbGetAll('pending_actions');
  const synced = all.filter(a => a.synced);
  for (const a of synced) await dbDelete('pending_actions', a.id);
}

// ============================================================
// EMPLOIS DU TEMPS HORS LIGNE
// ============================================================

export async function cacheEmploisDuTemps(edtList) {
  for (const edt of edtList) await dbPut('emplois_du_temps', edt);
  console.log('[IDB] Emplois du temps mis en cache ✓');
}

export async function getEmploisDuTempsOffline(classeId) {
  return dbGetAll('emplois_du_temps', 'classe_id', classeId);
}

// ============================================================
// SESSION UTILISATEUR
// ============================================================

export async function saveSession(userData) {
  await dbPut('session', { key: 'current_user', ...userData });
  console.log('[IDB] Session sauvegardée ✓');
}

export async function getSession() {
  return dbGet('session', 'current_user');
}

export async function clearSession() {
  return dbDelete('session', 'current_user');
}

// ============================================================
// SYNCHRONISATION MANUELLE
// ============================================================

export async function syncAllPendingData() {
  const pending = await getPendingActions();
  if (pending.length === 0) {
    console.log('[IDB] Aucune donnée en attente de synchronisation');
    return { synced: 0, errors: 0 };
  }

  console.log(`[IDB] Synchronisation de ${pending.length} action(s) en attente...`);
  let synced = 0;
  let errors = 0;
  const session = await getSession();
  const token = session?.token || '';

  for (const action of pending) {
    try {
      const response = await fetch(action.url, {
        method: action.method || 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: action.body
      });

      if (response.ok) {
        await deletePendingAction(action.id);
        synced++;
        console.log(`[IDB] Action ${action.id} synchronisée ✓`);
      } else {
        errors++;
        console.warn(`[IDB] Erreur sync action ${action.id}:`, response.status);
      }
    } catch (err) {
      errors++;
      console.warn(`[IDB] Action ${action.id} non synchronisée (hors ligne?)`, err);
    }
  }

  console.log(`[IDB] Sync terminée: ${synced} succès, ${errors} erreurs`);
  return { synced, errors };
}

// ============================================================
// STATISTIQUES DU CACHE LOCAL
// ============================================================

export async function getCacheStats() {
  const [eleves, classes, matieres, notes, paiements, pending] = await Promise.all([
    dbCount('eleves'),
    dbCount('classes'),
    dbCount('matieres'),
    dbCount('notes_offline'),
    dbCount('paiements_offline'),
    dbCount('pending_actions'),
  ]);
  return { eleves, classes, matieres, notes_offline: notes,
           paiements_offline: paiements, pending_actions: pending };
}

// ============================================================
// NETTOYAGE
// ============================================================

export async function clearAllOfflineData() {
  const db = await openDB();
  const stores = ['eleves', 'classes', 'matieres', 'emplois_du_temps',
                  'notes_offline', 'paiements_offline', 'pending_actions'];
  for (const store of stores) {
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).clear();
  }
  console.log('[IDB] Toutes les données hors ligne supprimées');
}

export { openDB };
