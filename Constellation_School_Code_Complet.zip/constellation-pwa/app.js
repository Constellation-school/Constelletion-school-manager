// ============================================================
// APP.JS — Serveur principal Constellation School
// Express.js + MySQL + PWA + JWT
// Patrick TALLA — Yaoundé, Cameroun — 2025
// ============================================================

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const morgan     = require('morgan');
const path       = require('path');
const compression= require('compression');
const rateLimit  = require('express-rate-limit');

const app  = express();
const PORT = process.env.PORT || 3000;

// ============================================================
// MIDDLEWARES DE SÉCURITÉ
// ============================================================

// En-têtes de sécurité HTTP
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc:  ["'self'"],
      scriptSrc:   ["'self'", "'unsafe-inline'"],
      styleSrc:    ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
      fontSrc:     ["'self'", "https://fonts.gstatic.com"],
      imgSrc:      ["'self'", "data:", "blob:"],
      connectSrc:  ["'self'", "https://graph.facebook.com", "https://api.monetbil.com"],
      workerSrc:   ["'self'"],
    },
  },
}));

// Compression des réponses (améliore les performances)
app.use(compression());

// Logging des requêtes
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// CORS
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true,
}));

// Parsing JSON
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ============================================================
// RATE LIMITING (protection contre les attaques)
// ============================================================

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,
  message: { error: 'Trop de tentatives. Réessayez dans 15 minutes.' }
});

const apiLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 100,
  message: { error: 'Trop de requêtes. Ralentissez.' }
});

// ============================================================
// FICHIERS STATIQUES (avec cache optimisé)
// ============================================================

// Cache long pour les assets (images, fonts, icons)
app.use('/icons', express.static(path.join(__dirname, 'public/icons'), {
  maxAge: '30d',
  immutable: true,
}));

// Service Worker et Manifest : PAS de cache (doivent toujours être frais)
app.get('/service-worker.js', (req, res) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Service-Worker-Allowed', '/');
  res.sendFile(path.join(__dirname, 'public/service-worker.js'));
});

app.get('/manifest.json', (req, res) => {
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Content-Type', 'application/manifest+json');
  res.sendFile(path.join(__dirname, 'public/manifest.json'));
});

// Fichiers publics généraux
app.use(express.static(path.join(__dirname, 'public'), {
  maxAge: '1d',
  etag: true,
}));

// ============================================================
// ENDPOINT DE VÉRIFICATION DE CONNEXION (pour offline.html)
// ============================================================

app.head('/api/ping', (req, res) => res.status(200).end());
app.get('/api/ping',  (req, res) => res.json({
  status: 'ok',
  app: 'Constellation School',
  version: '1.0.0',
  timestamp: new Date().toISOString()
}));

// ============================================================
// ROUTES API
// ============================================================

app.use('/api/auth',        authLimiter, require('./routes/auth'));
app.use('/api/eleves',      apiLimiter,  require('./routes/eleves'));
app.use('/api/classes',     apiLimiter,  require('./routes/classes'));
app.use('/api/notes',       apiLimiter,  require('./routes/notes'));
app.use('/api/bulletins',   apiLimiter,  require('./routes/bulletins'));
app.use('/api/paiements',   apiLimiter,  require('./routes/paiements'));
app.use('/api/personnel',   apiLimiter,  require('./routes/personnel'));
app.use('/api/dashboard',   apiLimiter,  require('./routes/dashboard'));
app.use('/api/communication',apiLimiter, require('./routes/communication'));
app.use('/api/emplois-du-temps', apiLimiter, require('./routes/emplois'));

// ============================================================
// ROUTE PRINCIPALE — Servir l'application React/Vue
// ============================================================

// Toutes les routes non-API renvoient l'index.html (SPA)
app.get('*', (req, res) => {
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Route API introuvable' });
  }
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

// ============================================================
// GESTION DES ERREURS GLOBALES
// ============================================================

app.use((err, req, res, next) => {
  console.error('[ERROR]', err.message, err.stack);
  const status = err.status || 500;
  res.status(status).json({
    error: process.env.NODE_ENV === 'production'
      ? 'Une erreur est survenue'
      : err.message,
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
  });
});

// ============================================================
// DÉMARRAGE DU SERVEUR
// ============================================================

app.listen(PORT, () => {
  console.log('');
  console.log('  ✦ ============================================= ✦');
  console.log('  ✦   CONSTELLATION SCHOOL — Serveur démarré      ✦');
  console.log('  ✦   Patrick TALLA — Yaoundé, Cameroun — 2025    ✦');
  console.log('  ✦ ============================================= ✦');
  console.log('');
  console.log(`  🌐  URL       : http://localhost:${PORT}`);
  console.log(`  🔒  Mode      : ${process.env.NODE_ENV || 'development'}`);
  console.log(`  💾  Base BDD  : ${process.env.DB_NAME}@${process.env.DB_HOST}`);
  console.log(`  📱  PWA       : Hors ligne activé`);
  console.log('');
});

module.exports = app;
