// ============================================================
// SERVICE WORKER — Constellation School PWA
// Mode hors ligne complet avec synchronisation
// Patrick TALLA — Yaoundé, Cameroun — 2025
// ============================================================

const CACHE_STATIC  = 'constellation-static-v1.0';
const CACHE_DATA    = 'constellation-data-v1.0';
const CACHE_IMAGES  = 'constellation-images-v1.0';

// Fichiers à mettre en cache immédiatement à l'installation
const STATIC_FILES = [
  '/',
  '/index.html',
  '/offline.html',
  '/app.js',
  '/style.css',
  '/register-sw.js',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
  '/manifest.json',
  // Pages principales de l'application
  '/dashboard',
  '/eleves',
  '/notes',
  '/paiements',
  '/communication',
  '/emplois-du-temps',
];

// Routes API dont les réponses sont mises en cache
const CACHEABLE_API = [
  '/api/eleves',
  '/api/classes',
  '/api/matieres',
  '/api/niveaux',
  '/api/periodes',
  '/api/emplois-du-temps',
  '/api/dashboard/stats',
];

// ---- INSTALLATION ----
self.addEventListener('install', event => {
  console.log('[SW] Installation de Constellation School v1.0');
  event.waitUntil(
    caches.open(CACHE_STATIC)
      .then(cache => {
        console.log('[SW] Mise en cache des fichiers statiques...');
        return cache.addAll(STATIC_FILES);
      })
      .then(() => {
        console.log('[SW] Installation terminée ✓');
        return self.skipWaiting();
      })
      .catch(err => console.error('[SW] Erreur installation:', err))
  );
});

// ---- ACTIVATION ----
self.addEventListener('activate', event => {
  console.log('[SW] Activation du service worker');
  event.waitUntil(
    caches.keys()
      .then(cacheNames => {
        return Promise.all(
          cacheNames
            .filter(name => ![CACHE_STATIC, CACHE_DATA, CACHE_IMAGES].includes(name))
            .map(name => {
              console.log('[SW] Suppression ancien cache:', name);
              return caches.delete(name);
            })
        );
      })
      .then(() => self.clients.claim())
      .then(() => console.log('[SW] Activation terminée ✓'))
  );
});

// ---- INTERCEPTION DES REQUÊTES ----
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  // Ignorer les requêtes non-GET et les extensions Chrome
  if (request.method !== 'GET') return;
  if (url.protocol === 'chrome-extension:') return;

  // 1. API données critiques → Network First (réseau, puis cache)
  if (CACHEABLE_API.some(path => url.pathname.startsWith(path))) {
    event.respondWith(networkFirstStrategy(request, CACHE_DATA));
    return;
  }

  // 2. Images → Cache First (cache, puis réseau)
  if (request.destination === 'image') {
    event.respondWith(cacheFirstStrategy(request, CACHE_IMAGES));
    return;
  }

  // 3. Tout le reste → Stale While Revalidate (cache immédiat + maj en arrière-plan)
  event.respondWith(staleWhileRevalidate(request, CACHE_STATIC));
});

// ============================================================
// STRATÉGIES DE CACHE
// ============================================================

// Réseau d'abord → fallback cache → page offline
async function networkFirstStrategy(request, cacheName) {
  try {
    const networkResponse = await fetch(request);
    if (networkResponse.ok) {
      const cache = await caches.open(cacheName);
      await cache.put(request, networkResponse.clone());
    }
    return networkResponse;
  } catch {
    const cached = await caches.match(request);
    if (cached) {
      console.log('[SW] Hors ligne — données servies depuis le cache:', request.url);
      return cached;
    }
    return new Response(
      JSON.stringify({ offline: true, message: 'Données non disponibles hors ligne' }),
      { headers: { 'Content-Type': 'application/json' } }
    );
  }
}

// Cache d'abord → fallback réseau
async function cacheFirstStrategy(request, cacheName) {
  const cached = await caches.match(request);
  if (cached) return cached;
  try {
    const networkResponse = await fetch(request);
    const cache = await caches.open(cacheName);
    await cache.put(request, networkResponse.clone());
    return networkResponse;
  } catch {
    return caches.match('/offline.html');
  }
}

// Cache immédiat + mise à jour en arrière-plan
async function staleWhileRevalidate(request, cacheName) {
  const cached = await caches.match(request);
  const fetchPromise = fetch(request)
    .then(response => {
      if (response.ok) {
        caches.open(cacheName).then(cache => cache.put(request, response.clone()));
      }
      return response;
    })
    .catch(() => cached || caches.match('/offline.html'));

  return cached || fetchPromise;
}

// ============================================================
// SYNCHRONISATION EN ARRIÈRE-PLAN (Background Sync)
// ============================================================

self.addEventListener('sync', event => {
  console.log('[SW] Événement sync reçu:', event.tag);
  if (event.tag === 'sync-notes') {
    event.waitUntil(syncNotes());
  }
  if (event.tag === 'sync-paiements') {
    event.waitUntil(syncPaiements());
  }
  if (event.tag === 'sync-all') {
    event.waitUntil(Promise.all([syncNotes(), syncPaiements()]));
  }
});

async function syncNotes() {
  console.log('[SW] Synchronisation des notes en attente...');
  try {
    // Récupérer les notes en attente depuis IndexedDB
    const pending = await getFromIndexedDB('notes_offline');
    let synced = 0;
    for (const note of pending) {
      try {
        const response = await fetch('/api/notes', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${note.token}`
          },
          body: JSON.stringify(note.data)
        });
        if (response.ok) {
          await deleteFromIndexedDB('notes_offline', note.id);
          synced++;
        }
      } catch (err) {
        console.warn('[SW] Erreur sync note:', err);
      }
    }
    console.log(`[SW] ${synced} note(s) synchronisée(s) ✓`);
    // Notifier l'utilisateur
    if (synced > 0) {
      self.registration.showNotification('Constellation School', {
        body: `${synced} note(s) synchronisée(s) avec le serveur ✓`,
        icon: '/icons/icon-192.png',
        badge: '/icons/icon-72.png',
      });
    }
  } catch (err) {
    console.error('[SW] Erreur syncNotes:', err);
  }
}

async function syncPaiements() {
  console.log('[SW] Synchronisation des paiements en attente...');
  try {
    const pending = await getFromIndexedDB('paiements_offline');
    let synced = 0;
    for (const paiement of pending) {
      try {
        const response = await fetch('/api/paiements', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${paiement.token}`
          },
          body: JSON.stringify(paiement.data)
        });
        if (response.ok) {
          await deleteFromIndexedDB('paiements_offline', paiement.id);
          synced++;
        }
      } catch (err) {
        console.warn('[SW] Erreur sync paiement:', err);
      }
    }
    console.log(`[SW] ${synced} paiement(s) synchronisé(s) ✓`);
  } catch (err) {
    console.error('[SW] Erreur syncPaiements:', err);
  }
}

// ============================================================
// NOTIFICATIONS PUSH
// ============================================================

self.addEventListener('push', event => {
  const data = event.data ? event.data.json() : {};
  const options = {
    body: data.message || 'Nouvelle notification Constellation School',
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-72.png',
    data: { url: data.url || '/' },
    actions: [
      { action: 'open',    title: 'Ouvrir' },
      { action: 'dismiss', title: 'Ignorer' },
    ],
  };
  event.waitUntil(
    self.registration.showNotification('✦ Constellation School', options)
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  if (event.action !== 'dismiss') {
    event.waitUntil(clients.openWindow(event.notification.data.url || '/'));
  }
});

// ============================================================
// HELPERS IndexedDB (dans le service worker)
// ============================================================

function openIndexedDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open('ConstellationDB', 1);
    req.onsuccess  = () => resolve(req.result);
    req.onerror    = () => reject(req.error);
  });
}

async function getFromIndexedDB(storeName) {
  const db = await openIndexedDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).getAll();
    req.onsuccess = () => resolve(req.result || []);
    req.onerror   = () => reject(req.error);
  });
}

async function deleteFromIndexedDB(storeName, id) {
  const db = await openIndexedDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const req = tx.objectStore(storeName).delete(id);
    req.onsuccess = () => resolve();
    req.onerror   = () => reject(req.error);
  });
}

console.log('[SW] ✦ Constellation School Service Worker chargé — Patrick TALLA 2025');
