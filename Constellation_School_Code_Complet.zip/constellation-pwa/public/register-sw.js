// ============================================================
// REGISTER-SW.JS — Enregistrement du Service Worker
// Gestion du mode hors ligne et de l'installation PWA
// Constellation School — Patrick TALLA — 2025
// ============================================================

// ---- ENREGISTREMENT DU SERVICE WORKER ----
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('/service-worker.js', {
        scope: '/'
      });

      console.log('✦ Constellation SW enregistré, scope:', registration.scope);

      // Écouter les mises à jour disponibles
      registration.addEventListener('updatefound', () => {
        const newWorker = registration.installing;
        newWorker.addEventListener('statechange', () => {
          if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
            showAppNotification(
              '🔄 Mise à jour disponible !',
              'Rechargez la page pour obtenir la dernière version de Constellation School.',
              'info',
              { label: 'Recharger', action: () => window.location.reload() }
            );
          }
        });
      });

      // Écouter les messages du service worker
      navigator.serviceWorker.addEventListener('message', event => {
        if (event.data.type === 'SYNC_COMPLETE') {
          const { synced, errors } = event.data;
          if (synced > 0) {
            showAppNotification(
              '✅ Synchronisation terminée',
              `${synced} élément(s) envoyé(s) au serveur avec succès.`,
              'success'
            );
            updatePendingBadge(0);
          }
        }
      });

    } catch (err) {
      console.error('Erreur enregistrement SW:', err);
    }
  });
}

// ============================================================
// DÉTECTION DU STATUT DE CONNEXION
// ============================================================

let wasOffline = false;

function updateConnectionStatus() {
  const isOnline = navigator.onLine;
  const offlineBar  = document.getElementById('offline-status-bar');
  const connDot     = document.getElementById('connection-status-dot');
  const connLabel   = document.getElementById('connection-status-label');

  // Mettre à jour la barre de statut
  if (offlineBar) {
    offlineBar.style.display = isOnline ? 'none' : 'flex';
  }

  // Mettre à jour le point de connexion dans la navbar
  if (connDot) {
    connDot.style.background = isOnline ? '#059669' : '#D97706';
    connDot.title = isOnline ? 'En ligne' : 'Hors ligne';
  }
  if (connLabel) {
    connLabel.textContent = isOnline ? 'En ligne' : 'Hors ligne';
    connLabel.style.color = isOnline ? '#059669' : '#D97706';
  }

  // Retour en ligne après une coupure
  if (isOnline && wasOffline) {
    wasOffline = false;
    showAppNotification(
      '🌐 Connexion rétablie !',
      'Synchronisation des données en cours...',
      'success'
    );
    triggerBackgroundSync();
    // Mise à jour manuelle si Background Sync non supporté
    if (!('SyncManager' in window)) {
      manualSync();
    }
  }

  // Vient de passer hors ligne
  if (!isOnline && !wasOffline) {
    wasOffline = true;
    showAppNotification(
      '⚡ Mode hors ligne activé',
      'Vos saisies sont sauvegardées localement et seront synchronisées au retour internet.',
      'warning',
      null,
      6000
    );
  }
}

// ---- DÉCLENCHEMENT DE LA SYNCHRONISATION ----
async function triggerBackgroundSync() {
  if ('serviceWorker' in navigator && 'SyncManager' in window) {
    try {
      const registration = await navigator.serviceWorker.ready;
      await registration.sync.register('sync-all');
      console.log('Background Sync déclenché ✓');
    } catch (err) {
      console.warn('Background Sync non disponible, sync manuelle...', err);
      manualSync();
    }
  } else {
    manualSync();
  }
}

// Synchronisation manuelle (fallback)
async function manualSync() {
  try {
    const { syncAllPendingData } = await import('/src/offline-db.js');
    const result = await syncAllPendingData();
    if (result.synced > 0) {
      showAppNotification(
        '✅ Synchronisation réussie',
        `${result.synced} élément(s) envoyé(s) au serveur.`,
        'success'
      );
      updatePendingBadge(0);
      // Recharger les données de la page courante
      window.dispatchEvent(new CustomEvent('data-refreshed'));
    }
  } catch (err) {
    console.error('Erreur synchronisation manuelle:', err);
  }
}

// Écouter les événements réseau
window.addEventListener('online',  updateConnectionStatus);
window.addEventListener('offline', updateConnectionStatus);
document.addEventListener('DOMContentLoaded', updateConnectionStatus);

// ============================================================
// BADGE DES DONNÉES EN ATTENTE
// ============================================================

export async function updatePendingBadge(count = null) {
  if (count === null) {
    try {
      const { countPendingActions } = await import('/src/offline-db.js');
      count = await countPendingActions();
    } catch { count = 0; }
  }

  const badge = document.getElementById('pending-sync-badge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }

  // API Badge du navigateur (icône de l'app)
  if ('setAppBadge' in navigator) {
    if (count > 0) {
      navigator.setAppBadge(count);
    } else {
      navigator.clearAppBadge();
    }
  }
}

// ============================================================
// NOTIFICATIONS DANS L'INTERFACE
// ============================================================

function showAppNotification(title, message, type = 'info', action = null, duration = 4500) {
  // Supprimer les notifications existantes
  document.querySelectorAll('.sw-notification').forEach(n => n.remove());

  const colors = {
    success: { bg: '#ECFDF5', border: '#059669', text: '#065F46', icon: '✅' },
    warning: { bg: '#FFFBEB', border: '#D97706', text: '#92400E', icon: '⚡' },
    error:   { bg: '#FEF2F2', border: '#DC2626', text: '#991B1B', icon: '❌' },
    info:    { bg: '#EEF4FF', border: '#1A73E8', text: '#1E3A8A', icon: 'ℹ️'  },
  };
  const c = colors[type] || colors.info;

  const notif = document.createElement('div');
  notif.className = 'sw-notification';
  notif.style.cssText = `
    position: fixed; bottom: 20px; left: 50%; transform: translateX(-50%);
    background: ${c.bg}; border: 1.5px solid ${c.border}; border-radius: 10px;
    padding: 12px 18px; max-width: 420px; width: 90%;
    display: flex; align-items: flex-start; gap: 10px;
    box-shadow: 0 8px 24px rgba(0,0,0,.15); z-index: 9999;
    font-family: 'Segoe UI', sans-serif; animation: slideUp .3s ease;
  `;

  notif.innerHTML = `
    <span style="font-size:18px;flex-shrink:0">${c.icon}</span>
    <div style="flex:1">
      <div style="font-size:13px;font-weight:700;color:${c.text};margin-bottom:2px">${title}</div>
      <div style="font-size:12px;color:${c.text};opacity:.85;line-height:1.5">${message}</div>
      ${action ? `<button onclick="${action.action.toString()}" style="
        margin-top:8px;background:${c.border};color:white;border:none;
        padding:5px 12px;border-radius:6px;font-size:12px;font-weight:600;cursor:pointer;
      ">${action.label}</button>` : ''}
    </div>
    <button onclick="this.parentElement.remove()" style="
      background:none;border:none;cursor:pointer;color:${c.text};opacity:.6;
      font-size:16px;line-height:1;flex-shrink:0;
    ">×</button>
  `;

  // Ajouter l'animation CSS
  if (!document.getElementById('sw-notif-style')) {
    const style = document.createElement('style');
    style.id = 'sw-notif-style';
    style.textContent = `
      @keyframes slideUp {
        from { transform: translateX(-50%) translateY(20px); opacity: 0; }
        to   { transform: translateX(-50%) translateY(0);    opacity: 1; }
      }
    `;
    document.head.appendChild(style);
  }

  document.body.appendChild(notif);
  setTimeout(() => {
    notif.style.opacity = '0';
    notif.style.transition = 'opacity .3s';
    setTimeout(() => notif.remove(), 350);
  }, duration);
}

// ============================================================
// PROMPT D'INSTALLATION PWA
// ============================================================

let deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;

  // Afficher le bouton d'installation
  const installBtn = document.getElementById('pwa-install-btn');
  if (installBtn) {
    installBtn.style.display = 'flex';
    installBtn.addEventListener('click', installPWA);
  }

  // Afficher une notification discrète après 30 secondes
  setTimeout(() => {
    if (deferredInstallPrompt) {
      showAppNotification(
        '📱 Installer Constellation School',
        'Ajoutez l\'application sur votre écran d\'accueil pour un accès rapide, même hors ligne !',
        'info',
        { label: 'Installer', action: installPWA },
        8000
      );
    }
  }, 30000);
});

// Installer l'application
window.installPWA = async function() {
  if (!deferredInstallPrompt) return;
  deferredInstallPrompt.prompt();
  const { outcome } = await deferredInstallPrompt.userChoice;
  console.log('Installation PWA:', outcome);
  if (outcome === 'accepted') {
    showAppNotification(
      '✦ Constellation School installé !',
      'L\'application est maintenant disponible sur votre écran d\'accueil.',
      'success'
    );
    const installBtn = document.getElementById('pwa-install-btn');
    if (installBtn) installBtn.style.display = 'none';
  }
  deferredInstallPrompt = null;
};

window.addEventListener('appinstalled', () => {
  console.log('✦ Constellation School PWA installée avec succès !');
  deferredInstallPrompt = null;
});

// Exporter les fonctions utiles
window.ConstellationOffline = {
  triggerSync: triggerBackgroundSync,
  updateBadge: updatePendingBadge,
  showNotif:   showAppNotification,
};
