// ============================================================
// SERVICES/WHATSAPP.JS — Service de messagerie WhatsApp
// Constellation School — Patrick TALLA — 2025
// ============================================================

const PHONE_ID = process.env.WA_PHONE_ID;
const WA_TOKEN = process.env.WA_TOKEN;
const API_URL  = `https://graph.facebook.com/v18.0/${PHONE_ID}/messages`;

// ---- MODÈLES DE MESSAGES ----
const TEMPLATES = {
  bulletin_disponible: (data) =>
    `✦ *Constellation School*\n\nBonjour ${data.parent_nom},\n\nLe bulletin de *${data.eleve_nom}* (${data.classe}) du *${data.trimestre}* est disponible.\n\n📊 Moyenne générale : *${data.moyenne}/20*\n🏆 Rang : *${data.rang}/${data.effectif}*\n📝 Mention : *${data.mention}*\n\nConsultez-le sur votre portail parent ou contactez l'administration.\n\n_Constellation School · Patrick TALLA, Directeur_`,

  relance_paiement: (data) =>
    `⚠️ *Constellation School — Rappel de paiement*\n\nBonjour ${data.parent_nom},\n\nNous vous rappelons qu'un solde de *${data.montant} FCFA* est en attente pour la scolarité de *${data.eleve_nom}* (${data.classe}).\n\n📅 Date limite : *${data.date_limite}*\n💳 Modes acceptés : Espèces, Orange Money, MTN MoMo\n\nMerci de régulariser votre situation dans les meilleurs délais pour éviter la suspension des cours.\n\n_Constellation School · +237 XXX XXX XXX_`,

  reunion_parents: (data) =>
    `📢 *Constellation School — Réunion Parents*\n\nBonjour ${data.parent_nom},\n\nNous vous convions à une réunion parents-professeurs :\n\n📅 Date : *${data.date}*\n🕐 Heure : *${data.heure}*\n📍 Lieu : *${data.lieu || 'Établissement Constellation School'}*\n📋 Objet : *${data.objet}*\n\nVotre présence est vivement souhaitée.\n\n_Constellation School · Patrick TALLA_`,

  alerte_absence: (data) =>
    `⚠️ *Constellation School — Alerte Absence*\n\nBonjour ${data.parent_nom},\n\n*${data.eleve_nom}* a été absent(e) le *${data.date}*${data.matiere ? ` en ${data.matiere}` : ''}.\n\nMerci de nous faire parvenir un justificatif dans les 48 heures (certificat médical ou mot d'excuse).\n\n_Constellation School · Surveillance Générale_`,

  recu_paiement: (data) =>
    `✅ *Constellation School — Reçu de Paiement*\n\n🧾 N° ${data.numero_recu}\n\n👤 Élève : ${data.eleve}\n🏫 Classe : ${data.classe}\n💰 Montant : *${data.montant} FCFA*\n💳 Mode : ${data.mode_paiement}\n📅 Date : ${data.date_paiement}\n\n✓ Paiement confirmé et enregistré.\n\n_Merci de conserver ce reçu. Constellation School · Patrick TALLA_`,

  fermeture_ecole: (data) =>
    `🏖️ *Constellation School — Information*\n\nBonjour,\n\nNous vous informons que l'établissement sera *fermé le ${data.date}* à l'occasion de *${data.raison}*.\n\nLes cours reprendront normalement le *${data.reprise}*.\n\nBonne journée !\n\n_Constellation School · Yaoundé, Cameroun_`,

  alerte_resultats: (data) =>
    `📉 *Constellation School — Alerte Résultats*\n\nBonjour ${data.parent_nom},\n\nNous souhaitons vous informer que la moyenne de *${data.eleve_nom}* est de *${data.moyenne}/20* ce trimestre, ce qui est en dessous de nos attentes.\n\nNous vous invitons à un entretien avec le professeur principal pour trouver des solutions d'amélioration.\n\n_Constellation School · Direction Pédagogique_`,

  message_libre: (data) =>
    `✦ *Constellation School*\n\n${data.message}\n\n_Constellation School · Patrick TALLA, Directeur · Yaoundé, Cameroun_`,
};

// ---- ENVOI D'UN MESSAGE WHATSAPP ----
async function envoyerMessage(telephone, type, data = {}) {
  if (!PHONE_ID || !WA_TOKEN) {
    console.warn('[WHATSAPP] Clés API non configurées — message non envoyé');
    return { success: false, reason: 'API non configurée' };
  }

  // Formater le numéro (supprimer le + et les espaces)
  const tel = telephone.replace(/[\s\+\-]/g, '');
  if (!tel || tel.length < 9) {
    return { success: false, reason: 'Numéro invalide' };
  }

  // Générer le message
  const templateFn = TEMPLATES[type];
  if (!templateFn) {
    return { success: false, reason: `Type de message inconnu: ${type}` };
  }
  const body = templateFn(data);

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${WA_TOKEN}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        recipient_type:    'individual',
        to:               tel,
        type:             'text',
        text:             { preview_url: false, body }
      })
    });

    const result = await response.json();

    if (!response.ok) {
      console.error('[WHATSAPP] Erreur API:', result);
      return { success: false, reason: result.error?.message || 'Erreur API', details: result };
    }

    console.log(`[WHATSAPP] Message "${type}" envoyé à ${tel} ✓`);
    return {
      success:    true,
      message_id: result.messages?.[0]?.id,
      to:         tel
    };

  } catch (err) {
    console.error('[WHATSAPP] Erreur réseau:', err.message);
    return { success: false, reason: err.message };
  }
}

// ---- ENVOI EN LOT (à plusieurs parents) ----
async function envoyerMessageEnLot(destinataires, type, dataFn) {
  const resultats = [];
  let  success = 0, errors = 0;

  for (const dest of destinataires) {
    const data   = typeof dataFn === 'function' ? dataFn(dest) : dataFn;
    const tel    = dest.mere_tel || dest.pere_tel || dest.tuteur_tel;
    if (!tel) { errors++; continue; }

    const result = await envoyerMessage(tel, type, data);
    resultats.push({ ...result, eleve: dest.eleve || dest.nom });
    if (result.success) success++;
    else errors++;

    // Pause de 100ms entre chaque envoi (limite Meta : 80 messages/sec)
    await new Promise(r => setTimeout(r, 100));
  }

  return { success, errors, total: destinataires.length, resultats };
}

// ---- ENVOI D'UN FICHIER (PDF de bulletin) ----
async function envoyerFichier(telephone, fileUrl, caption = '') {
  const tel = telephone.replace(/[\s\+\-]/g, '');

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${WA_TOKEN}`,
        'Content-Type':  'application/json',
      },
      body: JSON.stringify({
        messaging_product: 'whatsapp',
        to:               tel,
        type:             'document',
        document: {
          link:     fileUrl,
          caption:  caption || 'Bulletin Constellation School',
          filename: 'bulletin_constellation_school.pdf'
        }
      })
    });

    const result = await response.json();
    return { success: response.ok, message_id: result.messages?.[0]?.id };
  } catch (err) {
    return { success: false, reason: err.message };
  }
}

// ---- VÉRIFICATION DU WEBHOOK META ----
function verifyWebhook(req, res) {
  const mode      = req.query['hub.mode'];
  const token     = req.query['hub.verify_token'];
  const challenge = req.query['hub.challenge'];

  if (mode === 'subscribe' && token === process.env.WA_WEBHOOK_VERIFY_TOKEN) {
    console.log('[WHATSAPP] Webhook vérifié ✓');
    return res.status(200).send(challenge);
  }
  return res.status(403).json({ error: 'Token invalide' });
}

module.exports = {
  envoyerMessage,
  envoyerMessageEnLot,
  envoyerFichier,
  verifyWebhook,
  TEMPLATES,
};
