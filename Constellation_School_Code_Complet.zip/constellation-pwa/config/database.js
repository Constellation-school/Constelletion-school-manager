// ============================================================
// CONFIG/DATABASE.JS — Pool de connexions MySQL
// Constellation School — Patrick TALLA — 2025
// ============================================================

const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host:            process.env.DB_HOST     || 'localhost',
  port:            process.env.DB_PORT     || 3306,
  database:        process.env.DB_NAME     || 'constellation_school',
  user:            process.env.DB_USER     || 'constellation_user',
  password:        process.env.DB_PASS     || '',
  waitForConnections: true,
  connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT) || 10,
  queueLimit:      0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0,
  charset:         'utf8mb4',
  timezone:        '+01:00',
});

// Test de la connexion au démarrage
pool.getConnection()
  .then(conn => {
    console.log('  ✅  MySQL connecté avec succès !');
    conn.release();
  })
  .catch(err => {
    console.error('  ❌  Erreur connexion MySQL:', err.message);
  });

module.exports = pool;
